# Squid Bat Butterfly > 2022-05-07 11:58am
https://universe.roboflow.com/yolo-a6y21/squid-bat-butterfly

Provided by a Roboflow user
License: CC BY 4.0

